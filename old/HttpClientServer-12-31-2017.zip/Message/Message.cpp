///////////////////////////////////////////////////////////////////////////
// Message.cpp - defines message structure used in communication channel //
// ver 1.0                                                               //
// Jim Fawcett, CSE687-OnLine Object Oriented Design, Fall 2017          //
///////////////////////////////////////////////////////////////////////////

#include "Message.h"
#include <iostream>

using namespace HttpCommunication;
using SUtils = Utilities::StringHelper;

///////////////////////////////////////////////////////////////////////
// HttpCommand methods

//----< HttpCommand default constructor >------------------------------

HttpCommand::HttpCommand()
{
  cmd_ = GET;
  fileSpec_ = "foobar.htm";
}
//----< HttpCommand constructor >--------------------------------------

HttpCommand::HttpCommand(Command command, const std::string& fileSpec)
{
  cmd_ = command;
  fileSpec_ = fileSpec;
}
//----< promotion constructor >----------------------------------------

HttpCommand HttpCommand::fromString(const std::string& commStr)
{
  HttpCommand cmd;
  std::vector<std::string> splits = Utilities::StringHelper::split(commStr, ' ');
  std::string cmdStr;
  if (splits.size() > 1)
  {
    cmdStr = Utilities::StringHelper::trim(splits[0]);
    if (cmdStr == "GET") cmd.cmd_ = GET;
    if (cmdStr == "PUT") cmd.cmd_ = PUT;
    if (cmdStr == "POST") cmd.cmd_ = POST;
    if (cmdStr == "DELETE") cmd.cmd_ = DELETE;
    if (cmdStr == "HEAD") cmd.cmd_ = HEAD;
    cmd.fileSpec_ = Utilities::StringHelper::trim(splits[1]);
  }
  else
  {
    cmd.cmd_ = GET;
    cmd.fileSpec_ = "foobar.htm";
  }
  return cmd;
}

//----< return command string >----------------------------------------

std::string HttpCommand::toString() const
{
  std::string commandString;
  switch (cmd_)
  {
  case GET:
    commandString = "GET ";
    break;
  case PUT:
    commandString = "PUT ";
    break;
  case POST:
    commandString = "POST ";
    break;
  case DELETE:
    commandString = "DELETE ";
    break;
  case HEAD:
    commandString = "HEAD ";
    break;
  default:
    commandString = "GET ";
  }
  commandString += fileSpec_;
  commandString += " HTTP/1.0";
  return commandString;
}

//----< return command type >------------------------------------------

HttpCommand::Command HttpCommand::command() const
{
  return cmd_;
}
//----< set command type >---------------------------------------------

void HttpCommand::command(Command cmd)
{
  cmd_ = cmd;
}
//----< return command's file specification >--------------------------

std::string HttpCommand::fileSpec() const
{
  return fileSpec_;
}
//----< set command's file specification >-----------------------------

void HttpCommand::fileSpec(const std::string& fileSpec)
{
  fileSpec_ = fileSpec;
}

///////////////////////////////////////////////////////////////////////
// Message methods

//----< default constructor results in Message with no attributes >----

Message::Message() 
{
  cmd_.command(HttpCommand::GET);
  cmd_.fileSpec("");
}

//----< HTTP message constructor >-------------------------------------

Message::Message(HttpCommand::Command cmd, const std::string& fileSpecification) 
{
  cmd_.command(cmd);
  cmd_.fileSpec(fileSpecification);
}
//----< HTTP message copy constructor >--------------------------------

Message::Message(const Message& msg) : attributes_(msg.attributes_)
{
  Attributes temp = msg.attributes_;
  try
  {
    std::string lenStr = temp["content-length"];
    size_t sz = Utilities::Converter<size_t>::toValue(lenStr);
    pBody_ = new byte[sz];
    for (size_t i = 0; i < sz; ++i)
    {
      *pBody_ = msg.pBody_[i];
    }
  }
  catch (...)
  {
    pBody_ = nullptr;
  }
}
//----< HTTP message move constructor >--------------------------------

Message::Message(Message&& msg) : attributes_(msg.attributes_)
{
  pBody_ = msg.pBody_;
  msg.pBody_ = nullptr;
}
//----< HTTP message destructor >--------------------------------------

Message::~Message()
{
  delete[] pBody_;
}
//----< constructor accepting dst and src addresses >------------------

Message::Message(EndPoint to, EndPoint from)
{
  cmd_.command(HttpCommand::GET);
  cmd_.fileSpec("foobar.htm");
  attributes_["to"] = to.toString();
  attributes_["from"] = from.toString();
}
//----< HTTP message copy assignment >---------------------------------

Message& Message::operator=(const Message& msg)
{
  if (this != &msg)
  {
    attributes_ = msg.attributes_;

    Attributes temp = msg.attributes_;
    try
    {
      std::string lenStr = temp["content-length"];
      size_t sz = Utilities::Converter<size_t>::toValue(lenStr);
      pBody_ = new byte[sz];
      for (size_t i = 0; i < sz; ++i)
      {
        *pBody_ = msg.pBody_[i];
      }
    }
    catch (...)
    {
      pBody_ = nullptr;
    }
  }
  return *this;
}
//----< HTTP message move assignment >---------------------------------

Message& Message::operator=(Message&& msg)
{
  if (this != &msg)
  {
    attributes_ = msg.attributes_;
    pBody_ = msg.pBody_;
    msg.pBody_ = nullptr;
  }
  return *this;
}
//----< returns reference to Message attributes >----------------------

Message::Attributes& Message::attributes()
{
  return attributes_;
}
//----< adds or modifies an existing attribute >-----------------------

void Message::attribute(const Key& key, const Value& value)
{
  attributes_[key] = value;
}
//----< clears all attributes >----------------------------------------

void Message::clearAttributes()
{
  attributes_.clear();
}
//----< clears body bytes >--------------------------------------------

void Message::clearBody()
{
  delete[] pBody_;
  pBody_ = nullptr;
}
//----< clears message attributes and body >---------------------------

void Message::clear()
{
  clearAttributes();
  clearBody();
}
//----< returns vector of attribute keys >-----------------------------

Message::Keys Message::keys() const
{
  Keys keys;
  keys.reserve(attributes_.size());
  for (auto kv : attributes_)
  {
    keys.push_back(kv.first);
  }
  return keys;
}
//---< does this message have key? >-----------------------------------

bool Message::containsKey(const Key& key) const
{
  if (attributes_.find(key) != attributes_.end())
    return true;
  return false;
}
//----< get to attribute >---------------------------------------------

EndPoint Message::to()
{
  if (containsKey("to"))
  {
    return EndPoint::fromString(attributes_["to"]);
  }
  return EndPoint();
}
//----< set to attribute >---------------------------------------------

void Message::to(EndPoint ep)
{
  attributes_["to"] = ep.toString();
}
//----< get from attribute >-------------------------------------------

EndPoint Message::from()
{
  if (containsKey("from"))
  {
    return EndPoint::fromString(attributes_["from"]);
  }
  return EndPoint();
}
//----< set from attribute >-------------------------------------------

void Message::from(EndPoint ep)
{
  attributes_["from"] = ep.toString();
}
//----< get name attribute >-------------------------------------------

std::string Message::name()
{
  if (containsKey("name"))
  {
    return attributes_["name"];
  }
  return "";
}
//----< set name attribute >-------------------------------------------

void Message::name(const std::string& nm)
{
  attributes_["name"] = nm;
}
//----< get action attribute >-----------------------------------------

std::string Message::action()
{
  if (containsKey("action"))
  {
    return attributes_["action"];
  }
  return "";
}
//----< set action attribute >-----------------------------------------

void Message::action(const std::string& cmd)
{
  attributes_["action"] = cmd;
}
//----< get file name attribute >--------------------------------------

std::string Message::file()
{
  if (containsKey("file"))
  {
    return attributes_["file"];
  }
  return "";
}
//----< set file name attribute >--------------------------------------

void Message::file(const std::string& fl)
{
  attributes_["file"] = fl;
}
//----< get body length >----------------------------------------------

size_t Message::contentLength()
{
  if (containsKey("content-length"))
  {
    std::string lenStr = attributes_["content-length"];
    return Utilities::Converter<size_t>::toValue(lenStr);
  }
  return 0;
}
//----< set body length >----------------------------------------------

void Message::contentLength(size_t ln)
{
  attributes_["content-length"] = Utilities::Converter<size_t>::toString(ln);
}
//----< retrieve body pointer >----------------------------------------

const Message::byte* Message::body() const
{
  return pBody_;
}
//----< set body pointer >---------------------------------------------

void Message::body(Message::byte* pBody)
{
  pBody_ = pBody;
}
//----< convert message to string representation >---------------------

std::string Message::toString() const
{
  std::string temp = cmd_.toString();
  if(attributes_.size() > 0)
    temp += "\n";
  for (auto kv : attributes_)
  {
    temp += kv.first + ":" + kv.second + "\n";
  }
  return temp + "\n";
}
//----< extracts name from attribute string >--------------------------

Message::Key Message::attribName(const Attribute& attrib)
{
  size_t pos = attrib.find_first_of(':');
  if (pos == attrib.length())
    return "";
  return attrib.substr(0, pos);
}
//----< extracts value from attribute string >-------------------------

Message::Value Message::attribValue(const Attribute& attrib)
{
  size_t pos = attrib.find_first_of(':');
  if (pos == attrib.length())
    return "";
  return attrib.substr(pos + 1, attrib.length() - pos);
}
//----< creates message from message representation string >-----------

Message Message::fromString(const std::string& src)
{
  Message msg;
  std::vector<std::string> splits = Utilities::StringHelper::split(src, '\n');
  bool first = true;
  for (Attribute attr : splits)
  {
    if (first)
    {
      first = false;
      msg.cmd_ = HttpCommand::fromString(attr);
    }
    else
    {
      if (attribName(attr) != "")
        msg.attributes()[attribName(attr)] = attribValue(attr);
    }
  }
  return msg;
}
//----< displays message on std::ostream >-----------------------------
/*
*  - adds beginning newline and removes trailing newline
*  - by default stream is std::cout
*  - can be replaced by std::ostringstream to get display string
*/
std::ostream& Message::show(std::ostream& out)
{
  std::string temp = toString();  // convert this message to string
  size_t pos = temp.find_last_of('\n');
  if (pos < temp.size())
  {
    temp[pos] = '\0';  // remove last newline
  }
  out << "\n" << temp; // prepend newline
  return out;
}
//----< test stub >----------------------------------------------------

#ifdef TEST_MESSAGE

int main()
{
  SUtils::Title("Testing Message Class");

  SUtils::title("testing HTTP commands");
  Message get(HttpCommand::GET, "foobar.html");
  get.show();
  Message put(HttpCommand::PUT, "foobar.html");
  put.show();
  Message post(HttpCommand::POST, "foobar.html");
  post.show();
  Message del(HttpCommand::DELETE, "foobar.html");
  del.show();
  Message head(HttpCommand::HEAD, "foobar.html");
  head.show();
  Utilities::putline();

  SUtils::title("testing endpoints");
  EndPoint ep("localhost", 8080);
  std::cout << "\n  address = " << ep.address;
  std::cout << "\n  port = " << ep.port;
  std::string epStr = ep.toString();
  std::cout << "\n  " << epStr;

  EndPoint newEp = EndPoint::fromString(epStr);
  std::cout << "\n  " << newEp.toString();
  Utilities::putline();

  SUtils::title("testing messages");
  Utilities::putline();

  SUtils::title("creating message from Message::methods");
  Message msg;
  msg.name("msg#1");
  msg.to(EndPoint("localhost", 8080));
  msg.from(EndPoint("localhost", 8081));
  msg.action("doIt");
  msg.contentLength(42);
  msg.file("someFile");
  msg.show();

  SUtils::title("testing Message msg = fromString(msg.toString())");
  std::string test = msg.toString();
  Message newMsg = Message::fromString(msg.toString());
  newMsg.show();

  SUtils::title("retrieving attributes from message");
  std::cout << "\n  msg name          : " << newMsg.name();
  std::cout << "\n  msg action        : " << newMsg.action();
  std::cout << "\n  msg to            : " << newMsg.to().toString();
  std::cout << "\n  msg from          : " << newMsg.from().toString();
  std::cout << "\n  msg file          : " << newMsg.file();
  std::cout << "\n  msg content-Length: " << newMsg.contentLength();
  Utilities::putline();

  SUtils::title("adding custom attribute");
  newMsg.attribute("customName", "customValue");
  newMsg.show();

  SUtils::title("testing assignment");
  Message srcMsg;
  srcMsg.name("srcMsg");
  srcMsg.attribute("foobar", "feebar");
  srcMsg.show();
  std::cout << "\n  assigning srcMsg to msg #1";
  newMsg = srcMsg;
  newMsg.show();

  std::cout << "\n\n";
  return 0;
}
#endif
