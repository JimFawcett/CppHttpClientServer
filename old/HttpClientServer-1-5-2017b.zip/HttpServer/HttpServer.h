#pragma once
/////////////////////////////////////////////////////////////////////////
// HttpServer.h - Provides HTTP Message service                        //
//                                                                     //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2018           //
// Application: OOD Demo                                               //
// Platform:    Visual Studio 2015, Dell XPS 8900, Windows 10 pro      //
/////////////////////////////////////////////////////////////////////////
/*
* This package implements an HttpServer class that receives HTTP messages
* from multiple concurrent clients and simply displays them and simple
* reply.
*
* It's purpose is to provide a prototype for communication message for
* OOD projects.
*/
/*
* Required Files:
*   HttpServer.h, HttpServer.cpp
*   HttpClient.h, HttpClient.cpp
*   Message.h, Message.cpp
*   Sockets.h, Sockets.cpp,
*   Cppll-BlockingQueue.h
*   Logger.h, Logger.cpp
*   Utilities.h, Utilities.cpp
*/

template <typename T>
class HttpServer
{
public:
  HttpMessage<T> getMessage();
  void postMessage(HttpMessage<T> msg);
};