/////////////////////////////////////////////////////////////////////////
// StringServer.cpp - Demonstrates simple one-way string messaging     //
//                                                                     //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2016           //
// Application: OOD Project #4                                         //
// Platform:    Visual Studio 2015, Dell XPS 8900, Windows 10 pro      //
/////////////////////////////////////////////////////////////////////////
/*
* This package implements a server that receives string messages
* from multiple concurrent clients and simply displays them.
*
* It's purpose is to provide a very simple illustration of how to use
* the Socket Package provided for Project #4.
*/
/*
* Required Files:
*   StringClient.cpp, StringServer.cpp
*   Sockets.h, Sockets.cpp, Cppll-BlockingQueue.h
*   Logger.h, Logger.cpp, Cpp11-BlockingQueue.h
*   Utilities.h, Utilities.cpp
*/
#include "../Sockets/Sockets.h"
#include "../Logger/Logger.h"
#include "../Utilities/Utilities.h"
#include "../Message/Message.h"
#include <string>
#include <iostream>

using namespace Sockets;
using Show = StaticLogger<1>;

namespace HttpCommunication
{
  class ClientHandler
  {
  public:
    void operator()(Socket& socket_);
  };

  void ClientHandler::operator()(Socket& socket_)
  {
    static size_t count = 0;

    //while (true)
    {
      // read HTTP message header lines

      std::string msgString;
      while (socket_.validState())
      {
        std::string temp = socket_.recvString('\n');
        msgString += temp;
        if (temp.length() < 3 || !socket_.validState())  // temp = "\r\n" terminates headers
          break;
      }
      //std::cout << "\n" << msgString;
      size_t bytes = socket_.bytesWaiting();
      std::cout << "\n  bytes waiting = " << bytes;

      HttpMessage<HttpRequest> msg = HttpMessage<HttpRequest>::fromString(msgString);
      
      // read message body

      size_t bodyLen = msg.contentLength();
      //std::cout << "\n-- bodyLen = " << bodyLen;
      HttpMessageBody body;
      std::string temp;
      if (bodyLen > 0)
      {
        if (socket_.validState())
          std::cout << "\n  socket state is valid";
        else
          std::cout << "\n  socket state is invalid";
        body.size(bodyLen);
        socket_.recv(bodyLen, (Socket::byte*)(body.data().data()));
        temp = socket_.recvString('\n');
      }
      //std::cout << "\n  body = " << temp;
      msg.show();
      //std::cout << "\n-- server recvd message \n" + Utilities::StringHelper::trim(msgString) << std::endl;
      if (socket_.validState())
        std::cout << "\n  socket state is valid";
      else
        std::cout << "\n  socket state is invalid";

      size_t status = 200;
      std::string resource = msg.type().fileSpec();
      if (resource == "/favicon.ico")
      {
        status = 404;
        --count;
      }
      HttpMessage<HttpReply> reply = makeHttpReplyMessage(status);
      std::string replyStr = "<html><head><style>body { margin:5%; } font { font-family:tahoma; font-size:14; }";
      replyStr += "</style></head><body>";
      replyStr += "<h3>Got your message #" + Utilities::Converter<size_t>::toString(++count) + "</h3>";
      replyStr += "</body></html>";
      reply.body() = replyStr;
      reply.show();

      std::string sendStr = reply.toString();
      socket_.send(sendStr.size(), (Socket::byte*)sendStr.c_str());
      socket_.shutDown();
      //if (msg == "quit")
      //  break;
    }
  }
}
//----< test stub >--------------------------------------------------

using namespace HttpCommunication;

int main()
{
  Show::attach(&std::cout);
  Show::start();
  Show::title("Http Server started");
  try
  {
    SocketSystem ss;
    SocketListener sl(8080, Socket::IP6);
    ClientHandler cp;
    sl.start(cp);
    Show::write("\n --------------------\n  press key to exit: \n --------------------");
    std::cout.flush();
    std::cin.get();
  }
  catch (std::exception& exc)
  {
    Show::write("\n  Exeception caught: ");
    std::string exMsg = "\n  " + std::string(exc.what()) + "\n\n";
    Show::write(exMsg);
  }
}