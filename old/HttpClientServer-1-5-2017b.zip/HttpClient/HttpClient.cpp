/////////////////////////////////////////////////////////////////////////
// HttpClient.cpp - Demonstrates simple HTTP messaging                 //
//                                                                     //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2017           //
// Application: OOD Project #4                                         //
// Platform:    Visual Studio 2015, Dell XPS 8900, Windows 10 pro      //
/////////////////////////////////////////////////////////////////////////
/*
 * This package implements a client that sends string messages 
 * to a server that simply displays them.
 *
 * It's purpose is to provide a very simple illustration of how to use
 * the Socket Package provided for Project #4.
 */
/*
 * Required Files:
 *   StringClient.cpp, StringServer.cpp
 *   Sockets.h, Sockets.cpp
 *   Logger.h, Logger.cpp, Cpp11-BlockingQueue.h
 *   Utilities.h, Utilities.cpp
 */
#include "../Sockets/Sockets.h"
#include "../Logger/Logger.h"
#include "../Utilities/Utilities.h"
#include "../Message/Message.h"
#include <string>
#include <iostream>
#include <thread>

using Show = StaticLogger<1>;
using namespace Utilities;
using namespace Sockets;

namespace HttpCommunication
{
  /////////////////////////////////////////////////////////////////////
  // StringClient class
  // - was created as a class so more than one instance could be 
  //   run on child thread
  //
  class HttpClient
  {
  public:
    Message postMessage(Message& msg);
  private:
    SocketConnecter socket;
  };

 }

using namespace HttpCommunication;

Message HttpClient::postMessage(Message& msg)
{
  //msg.body()[10] = '\0';
  socket.connect("localhost", 8080);
  socket.sendString(msg.toString());
  size_t size = msg.body().size();
  if (size > 0)
  {
    std::string temp = msg.body().toString();
    std::cout << "\n  body = " << temp;
    socket.sendString(msg.body().toString());
    //socket.send(size, (Socket::byte*)(msg.body()).begin());
  }
  msg.show();
  Message reply(HttpRequest::GET, "foobar.htm");
  return reply;
}

int main()
{
  Show::title("Demonstrating HttpClient");
  SocketSystem ss;
  Message msg(HttpRequest::POST, "foobar.htm");
  msg.action("demo");
  msg.body() = "hello world\n";
  msg.contentLength(msg.body().size());
  msg.show();
  std::cout << msg.body().size();
  ::Sleep(1000);
  HttpClient client;
  client.postMessage(msg);

  Show::write("\n --------------------\n  press key to exit: \n --------------------");
  std::cout.flush();
  std::cin.get();
}