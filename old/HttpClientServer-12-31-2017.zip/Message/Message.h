#pragma once
/////////////////////////////////////////////////////////////////////////
// Message.h - defines HTTP message structure                          //
// ver 1.0                                                             //
// Jim Fawcett, CSE687 Object Oriented Design, Spring 2018             //
/////////////////////////////////////////////////////////////////////////
/*
*  Package Operations:
*  -------------------
*  This package defines an EndPoint struct and a Message class.  
*  - Endpoints define a message source or destination with an address and port number.
*  - Messages have an HTTP style structure with a set of attribute lines containing
*    name:value pairs.
*  - Message have a number of getter, setter methods for common attributes, and allow
*    definition of other "custom" attributes.
*
*  Required Files:
*  ---------------
*  Message.h, Message.cpp, Utilities.h, Utilities.cpp
*
*  Maintenance History:
*  --------------------
*  ver 1.1 : 28 Dec 2017
*  - added #include <iostream>
*  ver 1.0 : 03 Oct 2017
*  - first release
*
*/
#include "../Utilities/Utilities.h"
#include <string>
#include <unordered_map>
#include <vector>
#include <iostream>

namespace HttpCommunication
{
  ///////////////////////////////////////////////////////////////////
  // EndPoint struct

  struct EndPoint
  {
    using Address = std::string;
    using Port = size_t;
    Address address;
    Port port;
    EndPoint(Address anAddress = "", Port aPort = 0);
    std::string toString() const;
    static EndPoint fromString(const std::string& str);
  };

  inline EndPoint::EndPoint(Address anAddress, Port aPort) : address(anAddress), port(aPort) {}

  inline std::string EndPoint::toString() const
  {
    return address + ":" + Utilities::Converter<size_t>::toString(port);
  }

  inline EndPoint EndPoint::fromString(const std::string& str)
  {
    EndPoint ep;
    size_t pos = str.find_first_of(':');
    if (pos == str.length())
      return ep;
    ep.address = str.substr(0, pos);
    std::string portStr = str.substr(pos + 1);
    ep.port = Utilities::Converter<size_t>::toValue(portStr);
    return ep;
  }
  /////////////////////////////////////////////////////////////////////
  // HttpCommand class
  //
  class HttpCommand
  {
  public:
    enum Command { GET, PUT, POST, DELETE, HEAD };

    HttpCommand();
    HttpCommand(Command command, const std::string& fileSpec);
    std::string toString() const;
    static HttpCommand fromString(const std::string& cmdStr);
    Command command() const;
    void command(Command cmd);
    std::string fileSpec() const;
    void fileSpec(const std::string& fileSpec);
  private:
    Command cmd_;
    std::string fileSpec_;
  };

  ///////////////////////////////////////////////////////////////////
  // Message class
  //
  class Message
  {
  public:
    using Key = std::string;
    using Value = std::string;
    using Attribute = std::string;
    using Attributes = std::unordered_map<Key, Value>;
    using Keys = std::vector<Key>;
    using FileSpec = std::string;
    using CommandString = std::string;
    using byte = char;

    Message();
    Message(HttpCommand::Command command, const std::string& fileSpec);
    Message(EndPoint to, EndPoint from);
    Message(const Message& msg);
    Message(Message&& msg);
    ~Message();
    Message& operator=(const Message& msg);
    Message& operator=(Message&& msg);
    
    Attributes& attributes();
    void attribute(const Key& key, const Value& value);
    Keys keys() const;
    static Key attribName(const Attribute& attr);
    static Value attribValue(const Attribute& attr);
    bool containsKey(const Key& key) const;

    std::string file();
    void file(const std::string& fl);
    size_t contentLength();
    void contentLength(size_t ln);
    const byte* body() const;
    void body(byte* pByteArray);
    std::string name();
    void name(const std::string& nm);
    std::string action();
    void action(const std::string& cmd);
    EndPoint to();
    void to(EndPoint ep);
    EndPoint from();
    void from(EndPoint ep);
    void clearBody();
    void clearAttributes();
    void clear();
    std::string toString() const;
    static Message fromString(const std::string& src);
    std::ostream& show(std::ostream& out = std::cout);

  private:
    HttpCommand cmd_;
    Attributes attributes_;
    byte* pBody_ = nullptr;
    // name            : msgName
    // command         : msg Command
    // to              : dst EndPoint
    // from            : src EndPoint
    // file            : file name
    // content-length  : body length in bytes
    // custom attributes
  };
}